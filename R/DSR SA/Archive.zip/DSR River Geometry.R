####################### SEGMENT F
segment <- "F"                       #EDIT
depthToday <- cd2$dF1
segmentLength <- 23.4 * 5280 * 0.3048#EDIT   A=7.8mi, B=2.4mi, C=19.1mi, D=23.5mi, E=8.9mi, F=23.4mi, G=15.5mi
times <- length(depthToday)
source("C:\\Thesis\\LARB\\03 Thesis-Calcs\\4 Output Se Flux\\SubScripts\\SA River Geometry.R")

####################### SEGMENT G
segment <- "G"                       #EDIT
depthToday <- cd2$dG1
segmentLength <- 15.5 * 5280 * 0.3048#EDIT   A=7.8mi, B=2.4mi, C=19.1mi, D=23.5mi, E=8.9mi, F=23.4mi, G=15.5mi
times <- length(depthToday)
source("C:\\Thesis\\LARB\\03 Thesis-Calcs\\4 Output Se Flux\\SubScripts\\SA River Geometry.R")